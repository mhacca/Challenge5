/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challenge5;

import java.util.Scanner;

/**
 *
 * @author mariehaccandy
 */
public class Challenge5 {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) {
        String repeat = "yes";
        Scanner keyboard = new Scanner(System.in);

        do 
        {
            System.out.println("What word would you like to change?");
            if(){
                 String before = "xxhixx";
                 System.out.println("Before recursion: " + before);
                 String after = changeXY(before);
                 System.out.println("After recursion: " + after);
                 System.out.println("Do you wish to repeat?");
                 repeat = keyboard.nextLine();
                 
             }
            else if ()
             {
                 String before = "xhixhix";
                 System.out.println("Before recursion: " + before);
                 String after = changeXY(before);
                 System.out.println("After recursion: " + after);
                 System.out.println("Do you wish to repeat?");
                 repeat = keyboard.nextLine();
             }
            else ()
         {
                 String before = "codex";
                 System.out.println("Before recursion: " + before);
                 String after = changeXY(before);
                 System.out.println("After recursion: " + after);
                 System.out.println("Do you wish to repeat?");
                 repeat = keyboard.nextLine();
            }
                 
        } while (repeat.equalsIgnoreCase("yes"));
        keyboard.close();
// TODO code application logic here
    }
 public String changeXY(String str) 
    {
        if ( str.length() == 0)
        {
            return str;
        }
        else if (str.charAt(0)== 'x')
        {
            return 'y' + changeXY(str.substring(1));
        }
        return str.charAt(0) + changeXY(str.substring(1));
    }
 
}
